const myFullName = "Margish Rameshbhai Patoliya";
const myStudentNumber = "1163887";

console.log(`${myFullName} - ${myStudentNumber}`);

const header = document.querySelector("#headerContent");
header.innerHTML = `${myFullName} - ${myStudentNumber}`;
header.classList.add("headingPrimary");